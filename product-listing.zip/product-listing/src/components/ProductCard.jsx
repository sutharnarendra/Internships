import React from 'react'

function ProductCard({ name, price, image }) {
  return (
    <div style={{
      border: '1px solid #ddd',
      borderRadius: '10px',
      padding: '15px',
      textAlign: 'center',
      background: '#fff',
      boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
    }}>
      <img src={image} alt={name} style={{
        width: '100%',
        height: '180px',
        objectFit: 'contain',
        marginBottom: '10px'
      }} />
      <h3>{name}</h3>
      <p>${price}</p>
      <button style={{
        padding: '10px 20px',
        backgroundColor: '#202020',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer'
      }}>Buy Now</button>
    </div>
  )
}

export default ProductCard
