import React, { useState, useEffect } from 'react'
import ProductCard from './ProductCard'

function ProductList({ search }) {
  const [products, setProducts] = useState([])

  useEffect(() => {
    setProducts([
      {
        id: 1,
        name: 'ASUS Laptop',
        price: 1299,
        image: 'https://dlcdnwebimgs.asus.com/gain/4A228D80-A831-4FC5-AF5B-2730B1DAB010/w800'
      },
      {
        id: 2,
        name: 'NVIDIA RTX 5090',
        price: 1499,
        image: 'https://via.placeholder.com/300x200?text=RTX+5090'
      },
      {
        id: 3,
        name: 'PS5 Pro',
        price: 599,
        image: 'https://cdn.vox-cdn.com/thumbor/wYF7sppydCz_dIT0z7ccqBoBB0I=/0x0:2040x1360/1400x1050/filters:focal(847x517:1173x843):no_upscale()/cdn.vox-cdn.com/uploads/chorus_image/image/73214270/acastro_211201_4942_0002.0.jpg'
      },
      {
        id: 4,
        name: 'Laptop Cooling Pad',
        price: 49,
        image: 'https://m.media-amazon.com/images/I/71OdR7u7ZSL._AC_SL1500_.jpg'
      },
      {
        id: 5,
        name: 'WiFi Router Essentials',
        price: 89,
        image: 'https://m.media-amazon.com/images/I/41+R+WArI1L._AC_SL1000_.jpg'
      }
    ])
  }, [])

  const filtered = products.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      padding: '20px'
    }}>
      {filtered.map((product) => (
        <ProductCard key={product.id} {...product} />
      ))}
    </div>
  )
}

export default ProductList
