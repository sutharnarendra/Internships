import React, { useState } from 'react'
import ProductList from './components/ProductList'

function App() {
  const [search, setSearch] = useState('')

  const handleSearch = (e) => {
    setSearch(e.target.value)
  }

  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Tech Product Catalog</h1>
      <form style={{ textAlign: 'center', margin: '20px' }}>
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={handleSearch}
          style={{ padding: '10px', width: '300px' }}
        />
      </form>
      <ProductList search={search} />
    </div>
  )
}

export default App
